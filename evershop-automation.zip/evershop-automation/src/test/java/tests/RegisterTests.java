package tests;

import org.testng.annotations.Test;
import pages.RegisterPage;

public class RegisterTests extends BaseTest {

    @Test(groups = {"Functional"})
    public void testSuccessfulRegistration() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.register("Carlos", "carlos" + System.currentTimeMillis() + "@mail.com", "Passw0rd@123");
    }
}