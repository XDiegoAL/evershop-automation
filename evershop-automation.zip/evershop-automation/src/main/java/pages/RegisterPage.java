package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class RegisterPage extends BasePage {

    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    By firstName = By.name("firstName");
    By email = By.name("email");
    By password = By.name("password");
    By registerBtn = By.xpath("//button[contains(text(),'Create account')]");

    public void register(String name, String emailValue, String pass) {
    	wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).sendKeys(name);
    	driver.findElement(email).sendKeys(emailValue);
        driver.findElement(password).sendKeys(pass);
        driver.findElement(registerBtn).click();
    }
}